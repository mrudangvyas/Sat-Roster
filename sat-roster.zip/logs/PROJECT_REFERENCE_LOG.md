# SatRoster Project Reference Log

Generated on: March 5, 2026  
Repository path: `C:\Users\mrudang.vyas\Desktop\SatRoster`  
Purpose: Long-term technical reference covering project architecture, flow, frontend behavior, and session history.

## 1) Project Overview

SatRoster is a local-network scheduler for Saturday shift planning. It is a React + TypeScript single-page app served by an Express backend. The backend compiles Excel roster files into year-wise CSV payloads and exposes one API endpoint consumed by the frontend.

Primary business goal:
- Show yearly Saturday staffing by team.
- Allow filtering, planning, dependency analysis, and export/sharing workflows.

## 2) Stack and Runtime

Core stack:
- Frontend: React 18 + TypeScript + Vite.
- UI icons: `lucide-react`.
- Styling: Tailwind via CDN in `index.html` + custom CSS in `<style>`.
- Backend: Express 4 (ESM).
- Data ingestion: `xlsx` package reads `.xlsx` files at server startup.
- Process manager target: PM2 (`ecosystem.config.cjs`).

Ports:
- Backend/API default: `6175` (`server.js`).
- Frontend dev server: `6176` (`vite.config.ts`).
- Dev proxy: `/api` -> `http://localhost:6175`.

## 3) Repository Layout and Responsibilities

Top-level modules:
- `index.tsx`: React mount entrypoint.
- `App.tsx`: Main orchestrator for state, fetch, filters, view switching, and shared UI shell.
- `types.ts`: Shared domain typings.
- `dataProcessor.ts`: CSV parser and stats derivation.
- `constants.ts`: Timezone, fallback CSV (2026), app config.
- `calendarUtils.ts`: ICS generation and download.
- `server.js`: API + static hosting.
- `scheduleStore.js`: Loads XLSX files and builds `scheduleCsvByYear`.
- `components/*.tsx`: Feature views and UI submodules.
- `data/*.xlsx`: Source schedule spreadsheets.
- `dist/`: Built frontend artifacts (static hosting target).
- `logs/`: Intended project/reference logs.

Main feature components:
- `Dashboard.tsx`
- `ScheduleTable.tsx`
- `YearlyPlanner.tsx`
- `DependencyFinder.tsx`
- `YearPoster.tsx`
- `DayDetailDrawer.tsx`
- `FeatureGuide.tsx`
- `TeamCalendar.tsx`

## 4) End-to-End Data Flow

### 4.1 Backend ingestion flow

File: `scheduleStore.js`

1. Reads two workbook files from `data/`:
- `Updated_Saturday_Only_2026.xlsx`
- `Saturday_Roster_2027_2031.xlsx`
2. Uses first sheet only.
3. Normalizes rows to fixed header schema.
4. Groups rows by year (column index 3).
5. Escapes CSV values and builds one CSV blob per year.
6. Exposes:
- `scheduleCsvByYear: { [year]: csvString }`
- `availableScheduleYears: string[]`

### 4.2 API flow

File: `server.js`

Endpoint:
- `GET /api/schedule?year=YYYY`

Behavior:
1. Reads query `year`.
2. Falls back to default year `"2026"` if missing/invalid.
3. Returns JSON `{ csv, year }`.
4. If data missing entirely, returns `404`.

Static serving:
- Serves `dist/` assets.
- Wildcard route returns `dist/index.html` for SPA routing.

### 4.3 Frontend data flow

File: `App.tsx`

1. On `selectedYear` change:
- Calls `/api/schedule?year=<selectedYear>`.
- On success: `processScheduleData(payload.csv)`.
- On failure: falls back to `RAW_CSV_DATA` from `constants.ts`.
2. Parsed data becomes `data: ScheduleData`.
3. Global filters are applied to produce `filteredRecords`.
4. `deriveScheduleData(...)` recomputes stats from filtered set.
5. Active view renders one major component at a time.

## 5) Frontend Construction and Reactive Behavior

### 5.1 UI shell and global state

`App.tsx` owns:
- `view`: active tab (`dashboard`, `table`, `planner`, `dependency`, `poster`, `guide`).
- `selectedYear`: schedule year selector.
- `darkMode`: toggles `document.documentElement.classList`.
- `notes`: persisted to localStorage key `satroster_notes`.
- Filter states:
  - `selectedMonths` (state exists; no month picker currently wired in UI panel).
  - `selectedTeams`
  - `statusFilter` (`ALL | WORKING | OFF`)
  - `searchDate`
  - `onlyNotesFilter`
- `selectedDetailRecord`: opens right drawer details.
- `isFilterOpen`: toggles slide-over control panel.

Reactive behaviors:
- Data fetch re-runs on year change.
- Dark mode writes localStorage key `theme`.
- Notes auto-save to localStorage on each update.
- Filter changes propagate into all major views by operating on shared filtered dataset.

### 5.2 View-level behavior

Dashboard (`Dashboard.tsx`):
- Shows upcoming 5 Saturdays from current date.
- Calculates load labels (`Heavy/Medium/Light`) using thresholds in `APP_CONFIG`.
- Builds per-team cards with availability %, next working date, ICS export action.
- Provides team matrix modal via `TeamCalendar`.
- Can copy a sync summary to clipboard.

Schedule table (`ScheduleTable.tsx`):
- Tabular roster with per-row coverage metrics.
- Local quick filters: `Has Notes`, `High Coverage`, `Light Coverage`.
- Exports CSV snapshot including notes and coverage.
- Row copy helper generates share-ready formatted text.

Yearly planner (`YearlyPlanner.tsx`):
- Month cards with per-Saturday status indicators.
- Hover tooltip reveals full team status and note text.
- Visual density cues via colored markers.

Dependency finder (`DependencyFinder.tsx`):
- Select 2-6 teams.
- Two matching modes:
  - `INTERSECTION` (all selected teams must be working)
  - `THRESHOLD` (at least N selected teams working)
- Impact matrix flags critical overlap concentrations.
- Exports overlap CSV.

Poster mode (`YearPoster.tsx`):
- Print-friendly one-page yearly schedule layout.
- Uses `window.print()` and print CSS overrides.

Day detail drawer (`DayDetailDrawer.tsx`):
- Right-side panel for date details.
- Editable annotation with save action.
- Quick share templates: short, detailed, formal message.

Feature guide (`FeatureGuide.tsx`):
- In-app documentation cards for major features.

### 5.3 Styling and UI infrastructure

File: `index.html`

- Tailwind loaded through CDN and configured inline (`tailwind.config` in script).
- `brand` color scale defined.
- Custom CSS provides:
  - Glassmorphism surfaces (`.glass`).
  - Animated capacity rings/progress effects.
  - Gradient moving background (`.gradient-motion`).
  - Print helpers.
- App uses responsive shell:
  - Sticky top header (desktop controls).
  - Bottom floating nav on mobile.
  - Overlay filter drawer.

## 6) Domain Model

From `types.ts`:
- `Status`: `WORKING | OFF`
- `ScheduleRecord`: date, month, year, weekOfMonth, per-team status map.
- `TeamStats`: totals, percentage, next date, month breakdown.
- `ScheduleData`: records + teams + months + stats + global coverage.
- `NoteRecord`: keyed by `dateISO`.

## 7) Export and Integration Features

ICS:
- `calendarUtils.ts` generates RFC-style all-day events with exclusive `DTEND`.
- One ICS file per selected team from Dashboard.

CSV:
- Table export: full filtered table style rows.
- Dependency export: overlap-focused rows.

JSON:
- Notes export/import from App filter drawer:
  - Export file: `satroster_notes_backup.json`
  - Import merges entries into existing notes state.

## 8) Reconstructed Implementation Timeline (from file timestamps)

Note: `git` command is unavailable in this environment, so timeline is reconstructed from `LastWriteTime` metadata.

Date cluster: January 30, 2026 (single-day concentrated build activity)

Observed sequence:
1. Foundation files created/updated around 08:52 AM:
- `index.tsx`, `dataProcessor.ts`, `calendarUtils.ts`, `types.ts`, initial components, README.
2. Mid-morning feature expansion:
- `DependencyFinder.tsx` ~09:16 AM
- `ScheduleTable.tsx` ~09:17 AM
- `YearPoster.tsx` ~09:41 AM
- `FeatureGuide.tsx` ~09:51 AM
- `Dashboard.tsx` ~10:12 AM
3. Mid-afternoon infrastructure:
- `package.json` ~03:18 PM
- data files ~03:43 PM
- `constants.ts` ~03:50 PM
- `server.js` + `vite.config.ts` ~04:18 PM
- PM2 config + lockfile + `scheduleStore.js` through ~04:36 PM
4. Late-day integration pass:
- `YearlyPlanner.tsx` + `App.tsx` ~05:22 PM
- `index.html` styling/config ~05:26 PM
- `dist` build artifacts ~05:27 PM

## 9) Current Technical Risks and Gaps

1. Encoding artifacts in UI strings:
- Some literals render as garbled symbols in footer/share text in several components.

2. `index.html` has mixed setup patterns:
- Contains both import map references and Vite local module scripts.
- Includes duplicated module script entries (`index.tsx` and `/index.tsx`).

3. Date/time consistency:
- Most modules use `TIMEZONE = Asia/Kolkata`, but `DependencyFinder.tsx` uses raw `new Date().toISOString()` without timezone normalization.

4. Year hardcoding in export/share strings:
- Several filenames/texts embed `2026` even when selected year changes.

5. Filter state mismatch:
- `selectedMonths` exists and participates in filtering, but month selection UI is not present in control panel.

6. No automated tests found:
- No unit/integration test files or test script in `package.json`.

7. Runtime prerequisites not installed in current environment:
- `node_modules` absent; cannot execute app/build without `npm install`.

## 10) Session Discussion and Action Log (March 5, 2026)

User request summary:
- Asked for deep project analysis and creation of a future reference log including:
  - full project details
  - workflow explanation
  - frontend creation/reactivity details
  - discussion and implementation steps

Actions performed in this session:
1. Scanned repository structure and file inventory.
2. Reviewed core docs/configs (`README`, `package.json`, `tsconfig`, Vite, PM2, metadata).
3. Read backend and data ingestion pipeline (`server.js`, `scheduleStore.js`).
4. Read frontend entrypoint and main orchestrator (`index.tsx`, `App.tsx`).
5. Read all feature components and utility modules.
6. Collected file timestamps and code-size indicators.
7. Attempted to collect git history; blocked because `git` command is unavailable in environment.
8. Attempted runtime import of `scheduleStore.js`; blocked because dependencies are not installed (`xlsx` missing in node_modules).
9. Produced this comprehensive reference log file.

## 11) How to Extend This Log Going Forward

Recommended update pattern for future entries:
1. Add new section `Session Log - YYYY-MM-DD`.
2. Record:
- user request
- files touched
- behavior changes
- validation steps run
- known limitations
3. If available, append git commit hashes and PR links.

## Session Log - 2026-03-05 (UI Replication Continuation)

### User Request
- Continue UI replication from `C:\Users\mrudang.vyas\Downloads\teamsat-2026-visualizer` into current SatRoster project.
- Maintain a durable execution log so a VS Code crash does not lose session state.

### Work Completed
1. Added desktop team sidebar pattern similar to source project.
- New component: `components/TeamFilterSidebar.tsx`
- Features added:
  - Team list with `All` / `None` controls
  - Team checkbox toggling
  - Sync status card (`Teams Loaded`, `Active Schedule`)

2. Added floating assistant panel similar to source project.
- New component: `components/AssistantChat.tsx`
- Behavior:
  - Toggle button (`Ask Assistant`)
  - Local chat responses (no external API)
  - Supports:
    - direct date lookup using `YYYY-MM-DD`
    - `next saturday` query
    - `summary` / `coverage` query

3. Extended app filter model for reliable `All` vs `None` team behavior.
- Updated type model:
  - `types.ts` adds `TeamFilterMode = "all" | "custom"`
- `App.tsx` updates:
  - introduced `teamFilterMode`
  - added helpers:
    - `isTeamSelected`
    - `handleToggleTeam`
    - `handleSelectAllTeams`
    - `handleDeselectAllTeams`
  - updated filtering logic to handle:
    - all teams mode
    - custom team subset mode
    - explicit none-selected case

4. Added header CSV upload and restore flow (source-like shell behavior).
- `App.tsx` updates:
  - hidden file input ref
  - `Upload CSV` action in header
  - `Restore Default` action when custom CSV is active
  - local CSV parse via existing `processScheduleData`
  - upload status states:
    - `uploadedCsv`
    - `isImported`
    - `uploadError`

5. Added layout shell alignment with source pattern.
- Main area converted to desktop split layout:
  - left sticky sidebar (desktop)
  - right primary content area
- Mobile adds compact CSV upload button in content header.
- Assistant chat mounted globally in app shell.

6. Updated filter drawer team controls.
- Added `All` / `None` controls inside Control Panel team section.
- Team checkboxes now use shared selection handlers to keep behavior consistent across sidebar and drawer.

### Files Added
- `components/TeamFilterSidebar.tsx`
- `components/AssistantChat.tsx`

### Files Updated
- `App.tsx`
- `types.ts`

### Validation
- Build command run successfully:
  - Command: `npm.cmd run build`
  - Result: success
  - Output artifact:
    - `dist/assets/index-8beb2a44.js`
    - `dist/index.html`

### Environment Notes
- `npm run build` via PowerShell script shim failed due execution policy (`npm.ps1` unsigned).
- Working workaround used: `npm.cmd run build`.
- `git` command remains unavailable in this environment, so no commit hash was captured.

### Recovery Checkpoint (Use This After Crash)
If session is interrupted again, resume from these checkpoints:
1. Verify build still passes with `npm.cmd run build`.
2. Continue UI parity pass against source for any remaining component-level visual differences.
3. If needed, add richer assistant intents (currently local deterministic responses only).
4. Commit/branch tracking requires enabling `git` in PATH or installing Git.

## Session Log - 2026-03-05 (Filter System Alignment)

### User Request
- Review all app filters and align them with the reference project's dropdown-based filter UX.

### Filter Audit Summary
- Existing gaps identified:
  - Global Control Panel had no month/specific Saturday dropdown path.
  - Global status filter used button chips instead of dropdown.
  - Registry (`ScheduleTable`) used chip toggles only.
  - Dependency tab lacked month/date dropdown controls.

### Changes Implemented
1. Global Control Panel dropdown workflow in `App.tsx`
- Added state:
  - `selectedSaturday` (`"ALL" | dateISO`)
- Added derived dropdown options:
  - `saturdayDropdownOptions` (filtered by selected month)
- Added dropdown filters:
  - `Month` (`All Months` + dataset months)
  - `Specific Saturday` (`All Saturdays` + month-filtered dates)
  - `Status` converted to dropdown (`All Status`, `Working`, `Off`)
- Updated filter logic:
  - date matching now combines `selectedSaturday` + `searchDate`
- Updated filter indicator dot logic to include `selectedSaturday`.
- Updated filter reset to clear `selectedSaturday`.

2. Registry dropdown filter in `components/ScheduleTable.tsx`
- Replaced multi-chip `activeFilters` with single dropdown `activeFilter`.
- Added `Quick Filter` select:
  - `All Records`
  - `Has Notes`
  - `High Coverage`
  - `Light Coverage`
- Filtering now applies selected dropdown predicate.

3. Dependency tab dropdown filters in `components/DependencyFinder.tsx`
- Added dropdown states:
  - `selectedMonth`
  - `selectedDate`
- Added dropdown controls:
  - `Synergy Mode` (`Intersection`, `Threshold`)
  - `Month` (`All Months` + dataset months)
  - `Specific Saturday` (`All Saturdays` + month-filtered dates)
- Updated overlap filtering to respect month/date dropdowns.
- Added safety effects:
  - reset `selectedDate` if it becomes invalid after month change
  - clamp threshold when selected team count shrinks
- Replaced old mode toggle chips with mode summary block (`Mode Preview`) to avoid duplicate controls.

### Files Updated
- `App.tsx`
- `components/ScheduleTable.tsx`
- `components/DependencyFinder.tsx`

### Validation
- Command: `npm.cmd run build`
- Result: success
- Output artifact:
  - `dist/assets/index-84160625.js`

### Recovery Checkpoint
If editor crashes, resume from here:
1. Verify dropdown behavior in Control Panel:
  - Month -> Specific Saturday options narrow correctly.
  - Status dropdown affects filtered views.
2. Verify Registry `Quick Filter` dropdown states.
3. Verify Dependency dropdown filters (month/date/mode) affect overlaps.
4. Re-run `npm.cmd run build`.

## Session Log - 2026-03-05 (Discussion Ledger and Consolidated Notes)

### Purpose
- User requested explicit logging of all recent changes and discussions to prevent context loss after editor crashes.

### Discussion Timeline (User Queries + Outcomes)
1. Query: "The VS code was crashed. Can you check where were we?"
- Outcome:
  - Reconstructed current state from file timestamps/process state.
  - Identified latest edited UI files and recent successful build artifacts.
  - Confirmed active Vite process.

2. Query: "We were replicating UI from C:\\Users\\mrudang.vyas\\Downloads\\teamsat-2026-visualizer to our project"
- Outcome:
  - Compared source project structure/components with current project.
  - Identified completed replication vs pending parity areas.

3. Query: "yes please go ahead and please log everything"
- Outcome:
  - Implemented source-inspired shell pieces and persisted full logs.
  - Added sidebar/team selection, header CSV upload/restore, and assistant panel.

4. Query: "Why there is no data in the AIRAC tab?"
- Outcome:
  - Diagnosed that AIRAC CSV/parsing is valid and populated (2026 records exist).
  - Found runtime mismatch behavior where `/api/airac` on active path returned HTML instead of JSON in current run path, causing frontend fallback to empty records.
  - Clarified likely cause as server/proxy/runtime process mismatch.

5. Query: "Check all the filters and try to add dropdown filters same as the reference project UI."
- Outcome:
  - Completed dropdown-style filter alignment across global controls + registry + dependency views.
  - Verified with production build.

6. Query: "Please log all these changes and the discussions."
- Outcome:
  - Added this consolidated discussion ledger entry.

### Consolidated Change Set (Already Applied)
- UI replication shell:
  - `components/TeamFilterSidebar.tsx` (new)
  - `components/AssistantChat.tsx` (new)
  - `App.tsx` (integration/wiring)
  - `types.ts` (`TeamFilterMode`)
- Filter UX alignment:
  - `App.tsx`: month/saturday/status dropdown filters in Control Panel
  - `components/ScheduleTable.tsx`: `Quick Filter` dropdown
  - `components/DependencyFinder.tsx`: mode/month/saturday dropdown filter controls

### Validations Executed in Session
- `npm.cmd run build` successful after UI replication changes.
- `npm.cmd run build` successful after filter alignment changes.

### Operational Notes
- `npm` PowerShell shim may fail due execution policy (`npm.ps1` unsigned).
- Use `npm.cmd` commands as stable workaround in this environment.
- `git` is unavailable in PATH in current environment; commit hash logging not available until Git is accessible.

### Crash Recovery Anchor
If crash happens again, start from these checkpoints in order:
1. Open `logs/PROJECT_REFERENCE_LOG.md` and read the latest three sections:
  - UI Replication Continuation
  - Filter System Alignment
  - Discussion Ledger and Consolidated Notes
2. Run `npm.cmd run build`.
3. Validate AIRAC API path returns JSON from active runtime before debugging UI state.
4. Continue next UI parity tasks from pending component-level visual refinements.

## Session Log - 2026-03-05 (Loophole Remediation Pass)

### User Request
- "Please check the full project again and find loop holes."
- Follow-up: "yes please resolve and log all"

### Scope Executed
- Completed a full bug/risk review and then implemented direct code fixes for identified high-priority loopholes.
- Included additional low-risk stability/documentation fixes in the same pass.

### Issues Resolved

1. Dev API proxy/backend port mismatch (AIRAC endpoint instability)
- Problem:
  - Vite proxy backend target depended on generic `PORT`, causing accidental mismatch and `/api/airac` routing failures in some local runs.
- Fixes:
  - `vite.config.ts`
    - Proxy now reads dedicated backend env vars first:
      - `SATROSTER_BACKEND_PORT`
      - `VITE_BACKEND_PORT`
      - fallback `6175`
  - `package.json`
    - Added `dev:local` script for local backend-on-6715 runs:
      - `set SATROSTER_BACKEND_PORT=6715&& vite`
  - `ecosystem.config.cjs`
    - Added `SATROSTER_BACKEND_PORT: 6175` in frontend app env.

2. AIRAC requested-year vs fallback-year ambiguity
- Problem:
  - Backend fallback year could differ from requested year, but frontend always labeled UI using selected year only.
- Fixes:
  - `server.js`
    - `/api/airac` now returns metadata:
      - `requestedYear`
      - `resolvedYear`
      - `fallbackUsed`
      - `warning`
      - `availableYears`
  - `App.tsx`
    - Captures `airacResolvedYear`, `airacAvailableYears`, `airacWarning` from API response.
    - Displays AIRAC warning banner when fallback/unavailable occurs.
  - `components/AiracInsights.tsx`
    - Shows register badge using `resolvedYear`.
    - Shows explicit message when `selectedYear` differs from `resolvedYear`.

3. Imported CSV mode year mismatch / accidental cross-year behavior
- Problem:
  - Year selection could create confusion while uploaded CSV data is active.
- Fixes:
  - `App.tsx`
    - Added year lock behavior when imported CSV mode is active (`isYearLocked`).
    - Year dropdown options are disabled in imported mode.
    - Added user-facing schedule source notice for uploaded mode.
    - CSV upload now sets `selectedYear` directly from imported data year (not restricted to predefined year list).
    - Added `yearOptions` union list to include imported/custom year if needed.

4. Silent schedule fallback behavior
- Problem:
  - On schedule API failure, fallback to bundled raw data occurred silently.
- Fixes:
  - `App.tsx`
    - Added schedule source tracking (`api` / `fallback` / `uploaded`).
    - Added `scheduleWarning` banner in main content.
    - Explicit fallback warning now visible to user.

### Additional Stability Improvements

5. Dependency finder initialization safety
- File: `components/DependencyFinder.tsx`
- Fixes:
  - Guarded initial team selection for small/irregular team arrays.
  - Added team normalization effect when data changes.
  - Prevented overlap logic from returning false-positive full matches when no teams are selected.

6. Object URL lifecycle cleanup
- Added `URL.revokeObjectURL` after downloads in:
  - `App.tsx` (notes export)
  - `components/ScheduleTable.tsx` (table CSV export)
  - `components/DependencyFinder.tsx` (synergy CSV export)
  - `calendarUtils.ts` (ICS download)

7. Documentation correction and local workflow clarity
- File: `README.md`
- Fixes:
  - Corrected PM2 command from `ecosystem.config.js` to `ecosystem.config.cjs`.
  - Added local dual-terminal workflow for aligned backend+vite development:
    - `npm run start:local`
    - `npm run dev:local`

### Files Updated in This Pass
- `vite.config.ts`
- `package.json`
- `ecosystem.config.cjs`
- `server.js`
- `App.tsx`
- `components/AiracInsights.tsx`
- `components/DependencyFinder.tsx`
- `components/ScheduleTable.tsx`
- `calendarUtils.ts`
- `README.md`

### Validation Performed
1. Build validation
- Command: `npm.cmd run build`
- Result: success
- Artifact: `dist/assets/index-5b86cd13.js`

2. AIRAC API contract validation with fallback metadata
- Temp backend run on port `6191`.
- Request tested: `/api/airac?year=2030`
- Confirmed response includes:
  - non-empty `records`
  - `requestedYear: 2030`
  - `resolvedYear: 2026`
  - `fallbackUsed: true`
  - warning message and `availableYears`

### Operational Notes
- `npm` PowerShell shim may fail due execution policy in this environment.
- Use `npm.cmd ...` for reliable command execution on this machine.

### Recovery Anchor
If editor crashes, resume from this section and run:
1. `npm.cmd run build`
2. Start API: `npm run start:local`
3. Start FE with aligned proxy: `npm run dev:local`
4. Validate AIRAC fallback messaging by requesting an unavailable year and checking UI banner text.

### Addendum - 2026-03-05 (Remaining Medium Loopholes Closed)

Additional fixes applied after initial remediation block:

1. Schedule CSV parsing hardening (`dataProcessor.ts`)
- Parser now supports escaped quote sequences (`""`) correctly.
- Added explicit empty-input guard:
  - throws clear error when CSV input has no non-empty lines.

2. Clipboard error handling improvements
- Added failure handling for copy/share actions:
  - `components/Dashboard.tsx`
  - `components/ScheduleTable.tsx`
  - `components/DayDetailDrawer.tsx`
- Behavior now reports clipboard failures to user instead of assuming success.

3. Re-validation
- Command: `npm.cmd run build`
- Result: success
- Updated artifact: `dist/assets/index-71bcf7a7.js`

## Session Log - 2026-03-05 (Dev Proxy ECONNREFUSED Resolution)

### User-Observed Runtime Error
- Running `npm run dev` started Vite on `6176`, but API requests failed:
  - `/api/schedule?year=2026` -> `ECONNREFUSED`
  - `/api/airac?year=2026` -> `ECONNREFUSED`

### Root Cause
- Vite dev server was running without guaranteed backend server availability on the proxied API port.
- Existing workflow required manual two-process startup and was easy to desync.

### Fixes Applied
1. Unified dev launcher script
- Added new file: `scripts/dev-full.mjs`
- Behavior:
  - Starts backend (`server.js`) on configured backend port.
  - Starts Vite dev server on configured Vite port.
  - Wires Vite proxy to backend via `SATROSTER_BACKEND_PORT`.
  - Handles process shutdown on `SIGINT` / `SIGTERM`.
  - Detects pre-existing backend port usage and reuses existing backend instead of crashing.

2. Updated npm scripts
- `package.json`:
  - `dev` -> `node scripts/dev-full.mjs`
  - `dev:vite` -> raw Vite-only mode (`vite`)
  - `dev:local` -> local aligned launcher on backend `6715`

3. Updated docs
- `README.md`:
  - Added `npm run dev` as single-command development mode (backend + frontend).
  - Updated local guidance to use `npm run dev:local` as single-terminal flow.

### Validation Executed
1. Functional proxy checks through Vite:
- `http://localhost:6176/api/schedule?year=2026` -> HTTP 200
- `http://localhost:6176/api/airac?year=2026` -> HTTP 200

2. Build check:
- Command: `npm.cmd run build`
- Result: success

### Current Recommended Dev Commands
- Standard development:
  - `npm run dev`
- Local backend-on-6715 workflow:
  - `npm run dev:local`
- Backend-only (if needed):
  - `npm run start`
- Frontend-only (if backend already running):
  - `npm run dev:vite`

## Session Log - 2026-03-05 (Filter UI Relocation to Dashboard Only)

### User Request
- Remove shared filter UI that appears across tabs.
- Remove old filter panel behavior and place all filters inside Dashboard.

### Discussion Notes
- User confirmed intent to keep the filter controls but only expose them on Dashboard.
- User asked that all work and discussions be logged for crash recovery continuity.

### Changes Implemented
1. Removed shared cross-tab filter shell from `App.tsx`
- Removed desktop left sidebar rendering of `TeamFilterSidebar` from the app shell.
- Removed legacy right-side filter drawer block (`isFilterOpen` panel).
- Removed obsolete helper usage tied to that drawer block.

2. Kept global filter state in `App.tsx` and routed controls into Dashboard
- Dashboard call now receives all filter state and handlers:
  - month, specific saturday, status, search date, notes-only
  - team selection mode + team selection handlers
  - reset handler and year/import metadata
- Filter behavior remains global (same filtered dataset for all tabs), but UI controls now live only in Dashboard.

3. Added Dashboard-local filter UI in `components/Dashboard.tsx`
- Added `TeamFilterSidebar` inside Dashboard layout.
- Added new `Dashboard Filters` card with dropdowns and controls:
  - Month
  - Specific Saturday
  - Status
  - Search Date
  - Only with annotations
  - Reset Filters
- Added team selection summary line in filter card.

### Files Updated
- `App.tsx`
- `components/Dashboard.tsx`

### Validation
- Command: `npm.cmd run build`
- Result: success
- Artifact: `dist/assets/index-a13eceb0.js`

### Recovery Checkpoint
If VS Code crashes, resume from this section and verify:
1. Dashboard contains the only visible filter controls.
2. Other tabs no longer render shared filter sidebar/drawer UI.
3. Filters set on Dashboard still affect other tabs via shared filtered dataset.
4. Re-run `npm.cmd run build`.

### Addendum - 2026-03-05 (Guide Text Consistency)

- Updated `components/FeatureGuide.tsx` to match the new Dashboard-only filter workflow:
  - Removed old filter-icon/control-panel wording.
  - Updated text to direct users to Dashboard filters.
  - Updated Registry guidance from chips to `Quick Filter` dropdown.

Re-validation:
- Command: `npm.cmd run build`
- Result: success
- Updated artifact: `dist/assets/index-50d9c4e6.js`

## Session Log - 2026-03-05 (Dashboard Filter/Team Panel Compaction)

### User Request
- "Compact all these" for the Dashboard top filter area (Teams panel + Dashboard Filters card).

### Changes Implemented
1. Disabled stretch behavior for the two-column Dashboard filter row
- File: `components/Dashboard.tsx`
- Updated filter section grid to `items-start` so both cards size to content and do not force tall equal-height blocks.

2. Reduced Dashboard top-block spacing and control density
- File: `components/Dashboard.tsx`
- Tightened:
  - section gaps (`space-y`, `gap`)
  - heading sizes
  - card paddings (`p-6` -> `p-4`)
  - dropdown/input paddings (`py-2.5` -> `py-2`)
  - button sizes and typography
- Kept existing functionality unchanged.

3. Compacted Teams panel styling
- File: `components/TeamFilterSidebar.tsx`
- Tightened:
  - outer padding (`p-6` -> `p-4`)
  - title and action row spacing
  - team row spacing/padding
  - sync status card padding and typography
- Removed `h-full` stretch dependency for a more compact natural height.

### Files Updated
- `components/Dashboard.tsx`
- `components/TeamFilterSidebar.tsx`

### Validation
- Command: `npm.cmd run build`
- Result: success
- Artifact: `dist/assets/index-d599f1d3.js`

## Session Log - 2026-03-05 (Dashboard Team Filter Scope Fix)

### User Report
- Team filter selections in Dashboard were not visibly filtering Dashboard data.

### Root Cause
- `App.tsx` computed `filteredRecords`, but derived schedule stats were still built with full `data.teams`.
- As a result, Dashboard cards/stats continued to show all teams even in custom team mode.

### Fixes Applied
1. Team scope is now applied when deriving active schedule data
- File: `App.tsx`
- `filteredScheduleData` now calls `deriveScheduleData(filteredRecords, scopedTeams, nowISO)` where:
  - `scopedTeams = data.teams` in `all` mode
  - `scopedTeams = selectedTeams` in `custom` mode

2. Team-match logic cleanup in custom mode
- File: `App.tsx`
- Removed ineffective check `team in r.teams` (always true for valid team keys).
- Custom mode now only filters by status when a non-`ALL` status is selected.

3. Safety guard for coverage percentage
- File: `App.tsx`
- `deriveScheduleData` now guards division when `teams.length === 0`.

### Validation
- Command: `npm.cmd run build`
- Result: success
- Artifact: `dist/assets/index-57b5c6a6.js`

## Session Log - 2026-03-05 (Readability + Vertical Space Reduction)

### User Request
- Make the page easier to read by reducing space usage in:
  - top header
  - dashboard labels/title area
  - filters block

### Changes Implemented
1. Header density reduction (`App.tsx`)
- Reduced top bar vertical padding and control sizes.
- Reduced logo/icon sizes and title/subtitle text size.
- Tightened year selector and nav pill sizing.
- Reduced nav row bottom padding and tab button dimensions.

2. Removed duplicate Dashboard page label block (`App.tsx`)
- The app-level `Dashboard / <year> schedule workspace` heading is now hidden on Dashboard view.
- It still shows for non-dashboard tabs.
- Keeps only Live View / CSV controls on Dashboard to avoid duplicate title stacks.

3. Dashboard filters now collapsible (`components/Dashboard.tsx`)
- Added `Show Filters / Hide Filters` toggle button near top actions.
- Filter + teams panel is hidden by default to surface schedule cards earlier.
- When hidden, a compact summary line shows current team scope.

4. Dashboard title spacing cleanup (`components/Dashboard.tsx`)
- Slightly reduced top section spacing and subtitle text size.

### Files Updated
- `App.tsx`
- `components/Dashboard.tsx`

### Validation
- Command: `npm.cmd run build`
- Result: success
- Artifact: `dist/assets/index-3cc077f2.js`

## Session Log - 2026-03-05 (Teams Filter Converted to Dropdown Menu)

### User Request
- Convert the Teams filter panel from always-visible checkbox list to a dropdown selection menu.

### Changes Implemented
- File: `components/TeamFilterSidebar.tsx`

1. Converted Teams selector to dropdown-style menu
- Added trigger button showing current selection summary:
  - `All Teams`
  - `No Teams Selected`
  - `N Teams Selected`
- Added chevron indicator with open/close rotation.

2. Moved team checkboxes into popover menu
- Team checkbox list now appears inside dropdown panel.
- Preserved multi-select behavior via existing `onToggleTeam`.
- Preserved `All` / `None` actions in menu header.

3. Added click-outside close behavior
- Added outside-click listener to close dropdown when user clicks away.

### Files Updated
- `components/TeamFilterSidebar.tsx`

### Validation
- Command: `npm.cmd run build`
- Result: success
- Artifact: `dist/assets/index-4da34a7c.js`

## Session Log - 2026-03-10 (Full UI Shell Migration Toward `teamsat-2026-visualizer`)

### User Request
- Copy the styling and layout from `C:\Users\mrudang.vyas\Downloads\teamsat-2026-visualizer` and change the SatRoster UI accordingly.

### Work Completed
1. Replaced the app shell in `App.tsx` with a source-style layout.
- Sticky white header with source-like branding, upload action, year selector, and poster button.
- Restored a persistent left sidebar layout on desktop.
- Moved shared filters out of Dashboard and into the app shell sidebar to match the source project layout more closely.
- Replaced the old bottom mobile nav approach with source-style top tab chrome.
- Updated footer to source-style white bordered footer.

2. Rebuilt the left sidebar around the reference project pattern.
- Updated `components/TeamFilterSidebar.tsx` from dropdown menu behavior to an always-visible list card.
- Preserved SatRoster team filtering logic while changing the presentation to:
  - header with `All` / `None`
  - scrollable checkbox list
  - dark sync status card
- Added new file `components/ScheduleFilterPanel.tsx` for shared month/date/status/search/note filters in the same sidebar system.

3. Restyled Dashboard to fit the imported design system.
- Replaced Dashboard-local filter shell with content-only coverage view.
- Updated Dashboard cards to use source-style white cards, light borders, compact section headers, and simplified action buttons.
- Kept existing SatRoster behavior:
  - upcoming Saturdays
  - team availability cards
  - ICS export
  - team matrix modal
  - copy summary action

4. Aligned additional feature views away from the older glass-heavy treatment.
- `components/ScheduleTable.tsx`
  - moved toward white card + light table styling
  - updated export button and coverage/status colors to source-like blue/slate tones
- `components/DependencyFinder.tsx`
  - replaced glass/brand-heavy surfaces with white cards and light borders
  - aligned team selection and summary cards with the source palette
- `components/FeatureGuide.tsx`
  - converted guide cards to plain white bordered cards
- `components/DayDetailDrawer.tsx`
  - converted drawer to white panel + backdrop style closer to the source shell

5. Updated base document styling in `index.html`.
- Shifted body/background treatment to the source project's light slate page style.
- Added `custom-scrollbar` helpers used by the restored sidebar layout.

### Files Added
- `components/ScheduleFilterPanel.tsx`

### Files Updated
- `App.tsx`
- `components/Dashboard.tsx`
- `components/TeamFilterSidebar.tsx`
- `components/ScheduleTable.tsx`
- `components/DependencyFinder.tsx`
- `components/FeatureGuide.tsx`
- `components/DayDetailDrawer.tsx`
- `index.html`

### Validation
- Command: `npm.cmd run build`
- Result: success
- Artifact: `dist/assets/index-6144f7d8.js`

### Recovery Checkpoint
If the editor crashes after this UI migration:
1. Open this section in `logs/PROJECT_REFERENCE_LOG.md`.
2. Run `npm.cmd run build`.
3. Start the app and visually verify:
- header matches source shell
- left sidebar stays visible on desktop
- filters are now in the shared sidebar instead of Dashboard-only
- Dashboard, Registry, Dependency, Guide, and detail drawer all use the lighter source-inspired card styling

## Session Log - 2026-03-10 (Runtime Stabilization + V2 Feature Expansion)

### User Requests Covered
- Frontend not opening / blank browser page.
- Clarification on frontend vs backend port behavior.
- Remove sidebar `SYNC STATUS` card.
- Suggest useful new header and operations features.
- Implement all suggested features in **v2** UI.
- Persist all updates in this reference log.

### Runtime and Access Fixes
1. Frontend route reliability fix in Vite.
- File: `vite.config.ts`
- Added a Vite dev middleware plugin (`root-index-rewrite`) to rewrite `/` -> `/index.html` to avoid root-route 404/blank behavior in dev.

2. Port diagnosis and alignment.
- Verified runtime split:
  - Frontend (Vite): `6176`
  - Backend (Express API): `6175`
- Clarified behavior:
  - In dev, browser calls `6176`; Vite proxies `/api/*` to backend `6175`.
  - In production-style serving, frontend and API can be served by Express on one port.

3. Blank white screen root-cause fix.
- File: `App.tsx`
- Root cause: hook-order violation (memo hooks executed only after initial `data` load path).
- Fix: converted post-guard memoized calculations to stable non-hook computations so render hook order remains consistent.

### UI Cleanup Applied
1. Removed dark `SYNC STATUS` block from team sidebar.
- Files:
  - `components/TeamFilterSidebar.tsx`
  - `App.tsx`
- Removed status-card rendering and related prop wiring.

### V2 Feature Set Implemented
The following additions were implemented for v2 experience (`/v2` or `?ui=v2`):

1. Clickable header chips with navigation/filter actions
- Next Saturday, Coverage, AIRAC Active, Open Notes, Critical Overlap, Action Notes, AIRAC Conflicts.
- Chips now trigger contextual view/filter jumps.

2. Alert Center dropdown in header
- Prioritized operational alerts with direct actions:
  - API fallback mode
  - year integrity mismatch
  - critical overlaps
  - AIRAC proximity conflicts
  - action-required notes
  - stale data age warnings

3. Next-4 Saturdays strip
- Added compact interactive cards in header area.
- Clicking a card opens day detail.

4. Team Load Balance insight
- Added load-balance score, sigma, overloaded team, underused team metrics.

5. AIRAC conflict detector
- Added schedule-vs-AIRAC proximity check (window +/- 3 days around AIRAC start/closeout).
- Added counts in header and detail cards.

6. Interactive analytics enhancements
- Dashboard:
  - team workload distribution bars (click to focus/open matrix)
  - monthly load curve bars (click to apply month filter)
- AIRAC analytics already supported bar-click drilldown; retained and integrated in v2 flows.

7. Dependency impact heatmap
- File: `components/DependencyFinder.tsx`
- Added month x team heatmap with clickable cells to focus selection.
- Added optional conflict highlighting for overlap cards in enhanced mode.

8. Notes workflow states
- Added workflow states:
  - `none`
  - `note`
  - `action-required`
  - `resolved`
- State persisted to localStorage key `satroster_note_workflow`.
- Added:
  - filter control in sidebar
  - edit controls in day detail drawer
  - status display in schedule table
  - workflow counts in v2 insights

9. Data freshness and source audit panel
- Added audit panel in header with source mode and fetch-age telemetry.

10. Year compare mode
- Added toggle to compare selected year with previous year.
- Compares:
  - coverage delta
  - heavy overlap delta
  - AIRAC density delta

11. One-click export bundle
- Added bundled export action:
  - schedule CSV
  - AIRAC CSV
  - risk CSV
  - ops summary TXT

12. Keyboard quick actions (v2)
- `/` focuses Quick Jump
- `g d` -> Dashboard
- `g a` -> AIRAC
- `g n` -> Next Saturday detail

### Files Updated in This Session
- `App.tsx`
- `components/ScheduleFilterPanel.tsx`
- `components/DayDetailDrawer.tsx`
- `components/ScheduleTable.tsx`
- `components/Dashboard.tsx`
- `components/DependencyFinder.tsx`
- `vite.config.ts`

### Validation
- Command: `npm.cmd run build`
- Result: success
- Latest artifact sample: `dist/assets/index-0a6b9b56.js`

### V2 Entry URLs
- `http://localhost:6176/v2`
- `http://localhost:6176/?ui=v2`

## Session Log - 2026-03-13 (Dashboard Cleanup and Signal Tuning)

### User Requests
- Read all `.md` files in the workspace.
- Remove dashboard summary cards:
  - `Average Coverage`
  - `Teams In Scope`
  - `Upcoming Saturdays`
  - `Next Active Date`
- Remove `Search Date` from the `Selection Engine`.
- Remove `AIS Rotation` and `6 Teams` badges from the dashboard area.
- Change dashboard team-card availability thresholds to:
  - `High` for `> 70%` with green styling
  - `Medium` for `50%-70%`
  - `Low` for `< 50%` with red styling
- Reverse the signal meaning on `Upcoming 5 Saturdays` so:
  - `Heavy` = green
  - `Light` = red
- Remove availability from dashboard team cards only, while keeping availability elsewhere in the app.
- Persist the session into this project reference log.

### Actions Performed
1. Enumerated all Markdown files in the workspace and read them.
- Total `.md` files read: `218`
- Scope included repository-authored docs and dependency docs under `node_modules`.

2. Simplified dashboard framing UI.
- File: `components/Dashboard.tsx`
- Removed the top dashboard metric-card strip so the view starts directly with the remaining content sections.

3. Removed dashboard source/scope badges.
- File: `App.tsx`
- Removed the `AIS Rotation` and `6 Teams` badge row above the main content area.

4. Removed `Search Date` from sidebar filters.
- File: `components/ScheduleFilterPanel.tsx`
- Deleted the visible `Search Date` control from the `Selection Engine`.

5. Removed hidden search-date behavior.
- File: `App.tsx`
- Removed search-date participation from:
  - filtered record matching
  - active filter count
  - sidebar prop wiring
- This ensured no invisible date filter could keep affecting results after the UI field was removed.

6. Adjusted dashboard availability logic during iteration.
- File: `components/Dashboard.tsx`
- Added threshold-based availability styling for dashboard team cards as requested.
- Later, per follow-up request, removed availability entirely from those team cards.

7. Re-mapped `Upcoming 5 Saturdays` signal colors.
- File: `components/Dashboard.tsx`
- Updated load tone mapping so planning signals now read as:
  - `Heavy` -> green
  - `Medium` -> amber
  - `Light` -> red

8. Removed availability from dashboard team cards only.
- File: `components/Dashboard.tsx`
- Team cards now show:
  - team name
  - next working date
  - `View Matrix` button
- Availability remains present in other parts of the application where it was not explicitly targeted.

### Files Updated in This Session
- `App.tsx`
- `components/Dashboard.tsx`
- `components/ScheduleFilterPanel.tsx`
- `logs/PROJECT_REFERENCE_LOG.md`

### Resulting UX State
- Dashboard top summary cards are removed.
- `Selection Engine` no longer shows `Search Date`.
- Dashboard no longer shows `AIS Rotation` / `6 Teams` badges.
- `Upcoming 5 Saturdays` now uses planning-oriented signal colors:
  - heavy load = green
  - medium load = amber
  - light load = red
- Dashboard team cards no longer display availability.
- Availability elsewhere remains unchanged.

### Validation
- Command run repeatedly after UI changes: `npm.cmd run build`
- Final result: success
- Latest artifact sample: `dist/assets/index-b5b8a7f5.js`

## Session Log - 2026-03-19 (No-Visible-UX-Change Backend/Data Contract Fixes)

### User Direction
- Do not modify V2 UI behavior or layout.
- Apply only no-visible-UX-change fixes.

### Changes Implemented
1. Schedule API year-contract corrected.
- File: `server.js`
- `GET /api/schedule` now returns explicit resolution metadata aligned with AIRAC API:
  - `requestedYear`
  - `resolvedYear`
  - `fallbackUsed`
  - `availableYears`
  - `warning` (when fallback is applied)
- Backward compatibility preserved:
  - `year` still present, now aligned to the actual served schedule year (`resolvedYear`).

2. Frontend schedule fetch fallback hardened without layout changes.
- File: `App.tsx`
- Added in-memory schedule cache keyed by year from successful API responses.
- If schedule API is unavailable:
  - uses cached selected-year CSV when available;
  - otherwise uses bundled fallback CSV.
- Warning text now states whether fallback is cached-year or bundled default-year fallback.
- No visual/layout structure changes were made.

### Validation
1. Build validation:
- Command: `npm.cmd run build`
- Result: success
- Artifact sample: `dist/assets/index-d856b6e9.js`

2. API contract smoke test (local runtime):
- Started server on temporary port `6189`.
- Checked:
  - `/api/schedule?year=2027` -> `requestedYear=2027`, `resolvedYear=2027`, `fallbackUsed=false`.
  - `/api/schedule?year=2099` -> `requestedYear=2099`, `resolvedYear=2026`, `fallbackUsed=true`, warning present.

### Files Updated
- `server.js`
- `App.tsx`
- `logs/PROJECT_REFERENCE_LOG.md`

## Session Log - 2026-03-19 (AIRAC Cleanup + Team Mapping Precision Pass)

### User Suggestions Applied
1. Remove Register from AIRAC page.
2. Re-analyze Excel vs AIRAC team grouping and keep separate team lists for clean mapping.
3. Add matrix legend in Dashboard team matrix modal (blue = Working).
4. Keep Hitech on top in Team filter list.
5. Show all teams in upcoming Saturday cards (no `+1` / `+2` collapse).

### Data Verification Performed
Raw schedule headers from source workbooks:
- `Updated_Saturday_Only_2026.xlsx`:
  - `Charts + Minima+Mint+ENR`
  - `NFP+NOTAM+AODB`
  - `Nav+, +OBST`
  - `AIP capture`
  - `Geo`
  - `Hitech off`
- `Saturday_Roster_2027_2031.xlsx`:
  - `Charts + Minima+Mint+ENR`
  - `NFP+NOTAM+AODB`
  - `Nav+, OBST`
  - `AIP capture`
  - `Geo`
  - `Hitech off`

Raw AIRAC source teams from `AERO_Teams_Calendar_2026(AERO ).csv`:
- `Charts+Minima+Min+ENR`
- `NFP+NOTAM`
- `AODB Data team`
- `NAV+`
- `OBST Team`
- `AIP Capture`
- `Geo`

### Clean Mapping Model Implemented
Saturday combined team -> AIRAC source teams:
- `Charts + Minima+Mint+ENR` -> `Charts+Minima+Min+ENR`
- `NFP+NOTAM+AODB` -> `NFP+NOTAM`, `AODB Data team`
- `NAV+, OBST team` -> `NAV+`, `OBST Team`, `GS (AD+ENR+Proc)` (legacy-safe)
- `AIP capture` -> `AIP Capture`
- `Geo` -> `Geo`
- `Hitech` -> no AIRAC source team in current dataset

### UI/Behavior Changes Implemented
1. AIRAC page:
- File: `components/AiracInsights.tsx`
- Removed `Register` tab and its table view.
- Added explicit `Team Mapping Reference` card showing:
  - Saturday combined teams
  - AIRAC source teams list for each combined team
- Added unmapped AIRAC source warning section (if detected).

2. Team filter ordering:
- File: `components/TeamFilterSidebar.tsx`
- Pinned `Hitech` at top while preserving remaining order.

3. Matrix legend:
- File: `components/TeamCalendar.tsx`
- Added legend: blue fill indicates `Working`.

4. Upcoming Saturdays team chips:
- File: `components/Dashboard.tsx`
- Removed team-chip collapse (`+N`) and now renders all working teams.

### Validation
- Command: `npm.cmd run build`
- Result: success
- Artifact sample: `dist/assets/index-3c5a9ded.js`

### Files Updated
- `components/AiracInsights.tsx`
- `components/Dashboard.tsx`
- `components/TeamCalendar.tsx`
- `components/TeamFilterSidebar.tsx`
- `logs/PROJECT_REFERENCE_LOG.md`

## Session Log - 2026-03-19 (AIRAC Page Raw-Data-Only Correction)

### User Clarification
- AIRAC page should show only AIRAC data.
- Do not show Saturday-group labels/mapping labels inside AIRAC page timeline/analytics cards.

### Changes Implemented
- File: `components/AiracInsights.tsx`
- Removed Saturday-group presentation and mapping-reference UI from AIRAC page.
- AIRAC filter now uses only source team list:
  - `All AIRAC Source Teams`
  - individual source teams from CSV data.
- Timeline cards now display only AIRAC source team + AIRAC status/revision/dates.
- Analytics now aggregates by AIRAC source team (not mapped Saturday team).
- Retained existing timeline/analytics tabs and year fallback messaging.

### Validation
- Command: `npm.cmd run build`
- Result: success
- Artifact sample: `dist/assets/index-3ad06d8f.js`

### Files Updated
- `components/AiracInsights.tsx`
- `logs/PROJECT_REFERENCE_LOG.md`

## Session Log - 2026-03-19 (2026 Pattern Propagation to 2027-2031 Workbook)

### User Request
- Apply corrected Saturday pattern from:
  - `data/Updated_Saturday_Only_2026.xlsx`
- Into:
  - `data/Saturday_Roster_2027_2031.xlsx`
- Reason: 2026 roster had mistakes and was reissued; future workbook should follow corrected pattern.

### Analysis Performed
- Compared team-status vectors (columns 6-11) from corrected 2026 against 2027-2031 workbook.
- Found that only `Hitech off` values diverged from corrected pattern.
- Exact divergence before update:
  - 45 rows total
  - 9 rows per year for 2027, 2028, 2029, 2030, 2031

### Update Applied
- Rewrote team-status cells in `Saturday_Roster_2027_2031.xlsx` using corrected 2026 row-pattern cycle (52-row model).
- Date/calendar columns were kept unchanged.
- Result:
  - Pattern mismatches reduced from 45 to 0.

### Validation
- Pattern verification script:
  - Post-update mismatches vs corrected 2026 cycle: `0`
- Build validation:
  - Command: `npm.cmd run build`
  - Result: success
  - Artifact sample: `dist/assets/index-3ad06d8f.js`

### Files Updated
- `data/Saturday_Roster_2027_2031.xlsx`
- `logs/PROJECT_REFERENCE_LOG.md`

## Session Log - 2026-03-19 (Guide Tab Glossary Addition)

### User Request
- Add meanings of technical/jargon terms used in UI into the Guide tab.

### Changes Implemented
- File: `components/FeatureGuide.tsx`
- Added a new `Glossary` section in Guide tab with plain-language definitions for key terms:
  - AIRAC / NON-AIRAC
  - Revision / Closeout
  - Dependency / Intersection / Threshold
  - Matrix View / Coverage / Critical Overlap
  - Fallback Data
  - Combined team labels used in roster headers

### Validation
- Command: `npm.cmd run build`
- Result: success
- Artifact sample: `dist/assets/index-e69e1e8b.js`

### Files Updated
- `components/FeatureGuide.tsx`
- `logs/PROJECT_REFERENCE_LOG.md`

## Session Log - 2026-03-19 (Header/Dashboard UI Cleanup by Request)

### User Request
- Remove `Copy Team Sync` button.
- Remove `Live Schedule` label chip.
- Remove `Upload New CSV` action from header.

### Changes Implemented
1. Dashboard cleanup:
- File: `components/Dashboard.tsx`
- Removed `Live Schedule` badge.
- Removed `Copy Team Sync` button and related copy handler/import.

2. Header action cleanup:
- File: `App.tsx`
- Removed visible upload controls from header:
  - hidden file input hook-up for upload action in header block
  - `Upload New CSV` button
  - `Restore Default` link in same action cluster
- Kept poster action button.

### Validation
- Command: `npm.cmd run build`
- Result: success
- Artifact sample: `dist/assets/index-a8a13b8e.js`

### Files Updated
- `components/Dashboard.tsx`
- `App.tsx`
- `logs/PROJECT_REFERENCE_LOG.md`

## Session Log - 2026-03-19 (Undefined `scopedTeamCount` Fix)

### User Report
- TypeScript error in `App.tsx`:
  - `Cannot find name 'scopedTeamCount'. Did you mean 'scopedTeams'?`

### Fix Applied
- File: `App.tsx`
- Updated Team Scope badge value from undefined `scopedTeamCount` to `scopedTeams.length`.

### Validation
- Command: `npm.cmd run build`
- Result: success
- Artifact sample: `dist/assets/index-2ae26c2d.js`

### Files Updated
- `App.tsx`
- `logs/PROJECT_REFERENCE_LOG.md`

## Session Log - 2026-03-19 (Guide Content Alignment to Current App Surface)

### User Request
- Re-analyze Guide page and keep only feature guidance for functionality currently available in the app.

### Changes Implemented
- File: `components/FeatureGuide.tsx`
- Updated guide cards to match currently reachable app capabilities:
  - Dashboard
  - Details & Filters (Dashboard/Dependency/AIRAC scope)
  - AIRAC
  - Dependency Finder
  - Data Controls (Upload/Restore/Year/Poster)
  - Ask Assistant
- Removed outdated references from guidance text:
  - Yearly Planner as primary guided flow
  - Shift Registry flow references in guide steps
  - “next ten Saturdays” wording (now reflects current UI’s five-card view)

### Validation
- Command: `npm.cmd run build`
- Result: success
- Artifact sample: `dist/assets/index-c729baab.js`

### Files Updated
- `components/FeatureGuide.tsx`
- `logs/PROJECT_REFERENCE_LOG.md`
